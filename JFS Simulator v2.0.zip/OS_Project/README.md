# JFS Simulator v2.0
### Journaling File System Simulator — Professional Edition

---

## 🚀 Quick Start (3 ways to run)

### Method 1 — Double-click (No setup needed)
Just open `index.html` directly in your browser.
> Chrome / Edge / Firefox all work perfectly.

### Method 2 — Node.js Local Server (Recommended)
```bash
cd Rimmi
node server.js
```
Then open → **http://localhost:3000**

### Method 3 — Python HTTP Server
```bash
# Python 3
cd Rimmi
python -m http.server 3000
```
Then open → **http://localhost:3000**

---

## 📁 Project Structure

```
Rimmi/
├── index.html          ← Main HTML structure
├── server.js           ← Node.js local server
├── README.md           ← This file
├── css/
│   └── styles.css      ← Complete UI stylesheet
└── js/
    ├── simulator.js    ← WAL/Transaction engine
    ├── ui.js           ← UI rendering & animations
    └── app.js          ← Main app wiring & events
```

---

## 🎯 How to Use the Simulator

### Basic Transaction Flow:
1. **Go to Simulator** (sidebar)
2. Click **Start Transaction** → starts a new TX, writes BEGIN to WAL
3. Fill in filename, data, block ID, operation type
4. Click **Write Data** → stages write to WAL journal
5. Click **Write Data** again to add more writes (optional)
6. Click **Commit Transaction** → flushes all writes to disk atomically

### Crash & Recovery Demo:
1. **Start Transaction** → **Write Data** (do NOT commit)
2. Click **Simulate Crash** → see the kernel panic overlay
3. Observe disk blocks turn RED (corrupt)
4. Click **Initialize Recovery Sequence**
5. Watch the WAL recovery redo/undo committed/uncommitted writes
6. Disk blocks return GREEN — file system is consistent

### Step Replay:
- After running transactions, go to **Step Replay** page
- Use Prev/Next buttons or Auto Play to walk through every operation
- Each step explains what happened and why (great for learning)

---

## ⌨️ Keyboard Shortcuts

| Shortcut      | Action              |
|---------------|---------------------|
| `Ctrl + T`    | Start Transaction   |
| `Ctrl + W`    | Write Data          |
| `Ctrl + Enter`| Commit Transaction  |
| `Ctrl + Z`    | Rollback            |
| `Enter` (in input) | Write Data    |

---

## 📊 Features

| Feature | Description |
|---------|-------------|
| WAL Stream | Live table of every log record (LSN, TX, Op, File, Data, Timestamp) |
| Disk Block Map | 128 blocks visualized — Free/Pending/Committed/Corrupt |
| Journal Entries | Color-coded panel with all journal records |
| Transaction Timeline | Dashboard timeline of all TX events |
| Step Replay | Step-by-step walkthrough of every operation |
| Analytics | Charts (transaction history, operation breakdown) + ledger table |
| Learn JFS | 6 educational articles covering WAL, ACID, Recovery, Journaling Types |
| Settings | Journal mode, block size, crash probability, theme, accent color |
| Dark/Light Mode | Toggle via button or Settings page |
| 5 Accent Colors | Blue, Emerald, Amber, Rose, Violet |
| State Persistence | Saves to localStorage — reload and continue |
| Export | Download logs as TXT, full state as JSON |
| Hard Reset | Wipe everything and start fresh |

---

## 🧠 Concepts Demonstrated

- **Write-Ahead Logging (WAL)** — log before you write
- **ACID Properties** — Atomicity & Durability
- **Transaction State Machine** — IDLE → ACTIVE → WRITING → COMMITTED
- **Crash Simulation** — mid-transaction kernel panic
- **WAL Recovery** — REDO (committed TX) + UNDO (uncommitted TX)
- **Journaling Modes** — Full, Ordered, Writeback
- **Checkpoint** — flushing journal to disk
- **Log Sequence Numbers (LSN)** — ordering WAL records

---

## 🛠 Technical Stack

- **HTML5** — semantic structure
- **CSS3** — custom properties, grid, flexbox, animations
- **Vanilla JavaScript** — no frameworks, ES6+ modules pattern
- **Chart.js** — analytics charts (CDN)
- **Google Fonts** — IBM Plex Sans, IBM Plex Mono, Syne

---

*Built as a professional educational tool for Operating Systems / Database Systems courses.*
