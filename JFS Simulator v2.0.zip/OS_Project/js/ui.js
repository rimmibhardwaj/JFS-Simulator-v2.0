/**
 * ui.js
 * ─────────────────────────────────────────────────
 * All UI rendering, DOM manipulation, animations,
 * tooltips, toasts, navigation, and visual updates.
 * ─────────────────────────────────────────────────
 */

window.JFSUI = (function () {

  /* ── Page config ── */
  const PAGES = {
    dashboard: { title: 'Dashboard',   crumb: 'Overview'   },
    simulator: { title: 'Simulator',   crumb: 'Transaction Engine' },
    journal:   { title: 'Journal Log', crumb: 'WAL Records' },
    filesystem:{ title: 'File System', crumb: 'Disk State'  },
    replay:    { title: 'Step Replay', crumb: 'Transaction History' },
    analytics: { title: 'Analytics',   crumb: 'Metrics & Charts' },
    education: { title: 'Learn JFS',   crumb: 'Concepts'   },
    settings:  { title: 'Settings',    crumb: 'Configuration'},
  };

  let currentPage = 'dashboard';
  let charts = {};
  let replayIndex = 0;
  let replayAuto = null;
  let allLogs = [];
  let activeFilter = 'all';
  let logSearchTerm = '';

  /* ════════════════════════════════════════
     NAVIGATION
  ════════════════════════════════════════ */
  function initNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => navigateTo(item.dataset.page));
    });
  }

  function navigateTo(page) {
    if (!PAGES[page]) return;
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    // Show target
    document.getElementById(`page-${page}`).classList.add('active');
    document.querySelector(`[data-page="${page}"]`).classList.add('active');
    // Update topbar
    document.getElementById('pageTitle').textContent = PAGES[page].title;
    document.getElementById('breadcrumbCurrent').textContent = PAGES[page].crumb;
    currentPage = page;
    // Page-specific init
    if (page === 'analytics') refreshCharts();
    if (page === 'replay') refreshReplayList();
    if (page === 'education') initEducation();
    if (page === 'filesystem') refreshFileTree();
  }

  /* ════════════════════════════════════════
     SIDEBAR TOGGLE
  ════════════════════════════════════════ */
  function initSidebar() {
    document.getElementById('sidebarToggle').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('collapsed');
    });
  }

  /* ════════════════════════════════════════
     CLOCK
  ════════════════════════════════════════ */
  function startClock() {
    function tick() {
      const now = new Date();
      document.getElementById('topbarClock').textContent =
        now.toLocaleTimeString('en-US', { hour12: false });
    }
    tick();
    setInterval(tick, 1000);
  }

  /* ════════════════════════════════════════
     THEME
  ════════════════════════════════════════ */
  function initTheme() {
    const saved = localStorage.getItem('jfs_theme') || 'dark';
    setTheme(saved);
    document.getElementById('themeToggle').addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      setTheme(current === 'dark' ? 'light' : 'dark');
    });
    document.getElementById('settingTheme').addEventListener('change', e => {
      setTheme(e.target.value);
    });
  }

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('jfs_theme', theme);
    const sel = document.getElementById('settingTheme');
    if (sel) sel.value = theme;
    if (charts.tx) refreshCharts();
  }

  /* ════════════════════════════════════════
     TOOLTIP
  ════════════════════════════════════════ */
  function initTooltips() {
    const tip = document.getElementById('globalTooltip');
    document.querySelectorAll('[data-tooltip]').forEach(el => {
      el.addEventListener('mouseenter', e => {
        tip.textContent = el.dataset.tooltip;
        tip.classList.add('visible');
      });
      el.addEventListener('mousemove', e => {
        tip.style.left = (e.clientX + 14) + 'px';
        tip.style.top  = (e.clientY - 8) + 'px';
      });
      el.addEventListener('mouseleave', () => tip.classList.remove('visible'));
    });
  }

  /* ════════════════════════════════════════
     TOAST
  ════════════════════════════════════════ */
  function toast(type, title, msg, duration = 3500) {
    const icons = {
      info:    `<svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.3"/><path d="M8 7v4M8 5.5h.01" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`,
      success: `<svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.3"/><path d="M5 8l2.5 2.5L11 5.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
      warning: `<svg viewBox="0 0 16 16" fill="none"><path d="M8 2L1 14h14L8 2z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M8 7v3M8 11.5h.01" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`,
      error:   `<svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.3"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`,
    };
    const div = document.createElement('div');
    div.className = `toast toast-${type}`;
    div.innerHTML = `
      <div class="toast-icon">${icons[type] || icons.info}</div>
      <div class="toast-body">
        <div class="toast-title">${title}</div>
        ${msg ? `<div class="toast-msg">${msg}</div>` : ''}
      </div>`;
    document.getElementById('toastContainer').appendChild(div);
    setTimeout(() => {
      div.classList.add('removing');
      setTimeout(() => div.remove(), 280);
    }, duration);
  }

  /* ════════════════════════════════════════
     TX STATUS BADGE
  ════════════════════════════════════════ */
  function setTxStatus(state) {
    const el = document.getElementById('txStatus');
    el.textContent = state.toUpperCase();
    el.className = 'badge-value s-' + state.toLowerCase();
  }

  /* ════════════════════════════════════════
     SYSTEM STATUS
  ════════════════════════════════════════ */
  function setSystemStatus(status, text) {
    const dot = document.getElementById('systemStatusDot');
    const lbl = document.getElementById('systemStatusText');
    dot.className = 'status-dot ' + status;
    lbl.textContent = text;
  }

  /* ════════════════════════════════════════
     STATE MACHINE UI
  ════════════════════════════════════════ */
  const SM_MAP = {
    idle:       ['smIdle'],
    active:     ['smIdle','smActive'],
    writing:    ['smIdle','smActive','smWriting'],
    committed:  ['smIdle','smActive','smWriting','smCommitted'],
    crashed:    ['smCrashed'],
    recovering: ['smCrashed','smRecovering'],
    recovered:  ['smCrashed','smRecovering','smRecovered'],
  };

  function updateStateMachine(state) {
    document.querySelectorAll('.sm-state').forEach(el => el.classList.remove('active'));
    (SM_MAP[state] || []).forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.add('active');
    });
  }

  /* ════════════════════════════════════════
     WAL STREAM
  ════════════════════════════════════════ */
  function appendWALEntry(entry) {
    const container = document.getElementById('walStream');
    const placeholder = container.querySelector('.wal-placeholder');
    if (placeholder) placeholder.remove();

    const div = document.createElement('div');
    div.className = `wal-entry wal-entry-${entry.op}`;
    div.innerHTML = `
      <span class="wal-lsn">${String(entry.lsn).padStart(4,'0')}</span>
      <span class="wal-tx">${entry.txId}</span>
      <span class="wal-op wal-op-${entry.op}">${entry.op}</span>
      <span class="wal-file">${entry.file || '—'}</span>
      <span class="wal-data" title="${entry.payload}">${entry.payload || '—'}</span>
      <span class="wal-ts">${entry.ts}</span>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;

    // Update counter
    const cnt = container.children.length;
    document.getElementById('walEntryCount').textContent = `${cnt} records`;
  }

  function clearWALUI() {
    const container = document.getElementById('walStream');
    container.innerHTML = '<div class="wal-placeholder">WAL cleared. Start a new transaction to log entries.</div>';
    document.getElementById('walEntryCount').textContent = '0 records';
  }

  /* ════════════════════════════════════════
     JOURNAL ENTRIES PANEL
  ════════════════════════════════════════ */
  function appendJournalEntry(entry, status) {
    const container = document.getElementById('journalEntries');
    const empty = container.querySelector('.journal-empty');
    if (empty) empty.remove();

    const div = document.createElement('div');
    div.className = `journal-entry je-status-${status}`;
    div.innerHTML = `
      <div class="je-header">
        <span class="je-lsn">LSN:${entry.lsn}</span>
        <span class="je-op je-op-${entry.op}">${entry.op}</span>
        <span class="je-tx">${entry.txId}</span>
      </div>
      <div class="je-body">${entry.file ? `📄 ${entry.file}` : ''} ${entry.payload || ''}</div>
      <div class="je-time">${entry.ts}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;

    const cnt = container.children.length;
    document.getElementById('journalEntryCount').textContent = `${cnt} entries`;
    document.getElementById('navBadge').textContent = cnt;
  }

  /* ════════════════════════════════════════
     DISK BLOCK GRID
  ════════════════════════════════════════ */
  function initDiskGrid() {
    const grid = document.getElementById('diskGrid');
    grid.innerHTML = '';
    for (let i = 0; i < 128; i++) {
      const block = document.createElement('div');
      block.className = 'disk-block';
      block.id = `block-${i}`;
      block.title = `Block ${i + 1}`;
      block.addEventListener('click', () => showBlockInfo(i));
      grid.appendChild(block);
    }
  }

  function showBlockInfo(index) {
    const blocks = JFSSimulator.getDiskBlocks();
    const state = blocks[index];
    const fs = JFSSimulator.getFileSystem();
    const file = Object.values(fs).find(f => f.blocks && f.blocks.includes(index + 1));
    toast('info', `Block ${index + 1}`,
      `State: ${state.toUpperCase()} | ${file ? `File: ${file.name}` : 'Unallocated'}`
    );
  }

  function updateDiskUI(data) {
    const { blockId, state, diskBlocks } = data;

    if (blockId !== undefined) {
      const el = document.getElementById(`block-${blockId}`);
      if (el) {
        el.className = `disk-block ${state !== 'free' ? state : ''}`;
        el.title = `Block ${blockId + 1}: ${state}`;
        if (state === 'recovering') {
          setTimeout(() => {
            if (el) el.className = 'disk-block committed';
          }, 600);
        }
      }
    }

    if (diskBlocks) {
      // Update stats
      const used = diskBlocks.filter(b => b !== 'free').length;
      const committed = diskBlocks.filter(b => b === 'committed').length;
      const pending = diskBlocks.filter(b => b === 'written').length;
      const corrupt = diskBlocks.filter(b => b === 'corrupt').length;
      document.getElementById('diskUsed').textContent = used;
      document.getElementById('diskCommitted').textContent = committed;
      document.getElementById('diskPending').textContent = pending;
      document.getElementById('diskCorrupt').textContent = corrupt;
    }
  }

  function animateAllDiskBlocks(diskBlocks) {
    diskBlocks.forEach((state, i) => {
      setTimeout(() => {
        const el = document.getElementById(`block-${i}`);
        if (el) el.className = `disk-block ${state !== 'free' ? state : ''}`;
      }, i * 8);
    });
  }

  /* ════════════════════════════════════════
     TIMELINE
  ════════════════════════════════════════ */
  function addTimelineEntry(type, title, meta) {
    const container = document.getElementById('timelineContainer');
    const empty = container.querySelector('.timeline-empty');
    if (empty) empty.remove();

    const div = document.createElement('div');
    div.className = 'timeline-entry';
    div.innerHTML = `
      <div class="tl-dot tl-dot-${type}"></div>
      <div class="tl-content">
        <div class="tl-title">${title}</div>
        <div class="tl-meta">${meta}</div>
      </div>
      <div class="tl-time">${new Date().toLocaleTimeString('en-US',{hour12:false})}</div>`;
    container.prepend(div);
  }

  function clearTimeline() {
    document.getElementById('timelineContainer').innerHTML =
      '<div class="timeline-empty"><svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="20" stroke="currentColor" stroke-width="1.5" opacity="0.3"/><path d="M16 24h16M24 16v16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" opacity="0.5"/></svg><p>Timeline cleared.</p></div>';
  }

  /* ════════════════════════════════════════
     ACTIVITY FEED
  ════════════════════════════════════════ */
  function addActivity(type, text) {
    const list = document.getElementById('activityList');
    const empty = list.querySelector('.activity-empty');
    if (empty) empty.remove();

    const colors = { commit:'var(--green)', crash:'var(--red)', rollback:'var(--amber)', write:'var(--accent)', recover:'var(--purple)', start:'var(--teal)' };
    const item = document.createElement('div');
    item.className = 'activity-item';
    item.innerHTML = `
      <div class="act-dot" style="background:${colors[type]||'var(--accent)'}"></div>
      <div class="act-text">${text}</div>
      <div class="act-time">${new Date().toLocaleTimeString('en-US',{hour12:false})}</div>`;
    list.insertBefore(item, list.firstChild);
    while (list.children.length > 20) list.removeChild(list.lastChild);
  }

  /* ════════════════════════════════════════
     HEALTH METERS
  ════════════════════════════════════════ */
  function updateHealthMeters(state) {
    const configs = {
      idle:       { journal:100, fs:100, disk:0,  cache:0  },
      active:     { journal:100, fs:100, disk:10, cache:30 },
      writing:    { journal:100, fs:80,  disk:50, cache:60 },
      committed:  { journal:100, fs:100, disk:70, cache:80 },
      crashed:    { journal:70,  fs:20,  disk:50, cache:10 },
      recovering: { journal:90,  fs:60,  disk:50, cache:40 },
      recovered:  { journal:100, fs:100, disk:70, cache:80 },
    };
    const c = configs[state] || configs.idle;
    setMeter('meterJournal', 'meterJournalBar', c.journal);
    setMeter('meterFS',      'meterFSBar',      c.fs);
    setMeter('meterDisk',    'meterDiskBar',    c.disk);
    setMeter('meterCache',   'meterCacheBar',   c.cache);
  }

  function setMeter(labelId, barId, val) {
    document.getElementById(labelId).textContent = val + '%';
    document.getElementById(barId).style.width = val + '%';
  }

  /* ════════════════════════════════════════
     WAL DIAGRAM ANIMATION
  ════════════════════════════════════════ */
  function animateWALDiagram(activeStage) {
    document.querySelectorAll('.wal-stage').forEach(s => s.classList.remove('active'));
    if (activeStage) {
      const el = document.getElementById(activeStage);
      if (el) el.classList.add('active');
    }
  }

  /* ════════════════════════════════════════
     STATS UPDATE
  ════════════════════════════════════════ */
  function updateStats(stats) {
    document.getElementById('statTx').textContent = stats.transactions;
    document.getElementById('statCommits').textContent = stats.commits;
    document.getElementById('statCrashes').textContent = stats.crashes;
    document.getElementById('statWAL').textContent = stats.walEntries;
    document.getElementById('statFiles').textContent = stats.files;
  }

  /* ════════════════════════════════════════
     LOG TERMINAL
  ════════════════════════════════════════ */
  function appendLog(entry) {
    allLogs.push(entry);

    const terminal = document.getElementById('logTerminal');
    const div = document.createElement('div');
    div.className = `log-line log-${entry.level}`;
    div.dataset.level = entry.level;
    div.dataset.msg = (entry.msg + ' ' + (entry.detail || '')).toLowerCase();
    div.innerHTML = `
      <span class="log-time">${entry.time}</span>
      <span class="log-level log-level-${entry.level}">[${entry.level.toUpperCase()}]</span>
      <span class="log-msg">${entry.msg}</span>
      <span class="log-detail">${entry.detail || ''}</span>`;
    terminal.insertBefore(div, terminal.querySelector('.terminal-prompt').nextSibling);
    applyLogFilters();
  }

  function applyLogFilters() {
    const lines = document.querySelectorAll('#logTerminal .log-line');
    lines.forEach(line => {
      const matchFilter = activeFilter === 'all' || line.dataset.level === activeFilter;
      const matchSearch = !logSearchTerm || line.dataset.msg.includes(logSearchTerm.toLowerCase());
      line.classList.toggle('hidden', !(matchFilter && matchSearch));
    });
  }

  function initLogControls() {
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeFilter = btn.dataset.filter;
        applyLogFilters();
      });
    });
    document.getElementById('logSearch').addEventListener('input', e => {
      logSearchTerm = e.target.value;
      applyLogFilters();
    });
    document.getElementById('clearAllLogs').addEventListener('click', () => {
      allLogs = [];
      const terminal = document.getElementById('logTerminal');
      terminal.querySelectorAll('.log-line').forEach(l => l.remove());
      toast('info', 'Logs cleared', '');
    });
    document.getElementById('exportLogs').addEventListener('click', () => {
      const text = allLogs.map(l => `[${l.time}] [${l.level.toUpperCase()}] ${l.msg} ${l.detail}`).join('\n');
      downloadFile('jfs-logs.txt', text, 'text/plain');
      toast('success', 'Logs exported', 'jfs-logs.txt');
    });
  }

  /* ════════════════════════════════════════
     FILE TREE
  ════════════════════════════════════════ */
  function refreshFileTree() {
    const fs = JFSSimulator.getFileSystem();
    const children = document.getElementById('fsTreeChildren');
    const badge = document.getElementById('fsBadge');
    const files = Object.values(fs);
    badge.textContent = `${files.length} file${files.length !== 1 ? 's' : ''}`;

    if (files.length === 0) {
      children.innerHTML = '<div class="tree-empty-msg">No committed files yet.</div>';
      return;
    }

    children.innerHTML = '';
    files.forEach(file => {
      const el = document.createElement('div');
      el.className = 'tree-file';
      el.innerHTML = `
        <svg viewBox="0 0 16 16" fill="none"><path d="M3 2h7l3 3v9H3V2z" stroke="currentColor" stroke-width="1.2"/><path d="M10 2v3h3" stroke="currentColor" stroke-width="1.2"/></svg>
        <span>${file.name}</span>
        <span class="tree-badge">${formatBytes(file.size || 0)}</span>`;
      el.addEventListener('click', () => showFileInspector(file));
      children.appendChild(el);
    });
  }

  function showFileInspector(file) {
    document.querySelectorAll('.tree-file').forEach(f => f.classList.remove('selected'));
    event.currentTarget.classList.add('selected');

    const inspector = document.getElementById('fsInspector');
    inspector.innerHTML = `
      <div class="inspector-field"><span class="if-key">Name</span><span class="if-val">${file.name}</span></div>
      <div class="inspector-field"><span class="if-key">Size</span><span class="if-val">${formatBytes(file.size || file.data?.length || 0)}</span></div>
      <div class="inspector-field"><span class="if-key">Blocks</span><span class="if-val">${(file.blocks||[]).join(', ') || '—'}</span></div>
      <div class="inspector-field"><span class="if-key">Operation</span><span class="if-val">${file.operation || 'WRITE'}</span></div>
      <div class="inspector-field"><span class="if-key">Created</span><span class="if-val">${file.createdAt || '—'}</span></div>
      <div class="inspector-field"><span class="if-key">Modified</span><span class="if-val">${file.updatedAt || '—'}</span></div>
      <div class="inspector-field"><span class="if-key">Status</span><span class="if-val" style="color:var(--green)">✓ COMMITTED</span></div>
      <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border-subtle)">
        <div style="font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--text-muted);margin-bottom:8px">Content</div>
        <div style="font-family:var(--font-mono);font-size:.72rem;color:var(--text-secondary);background:var(--bg-elevated);padding:10px;border-radius:var(--radius-sm);word-break:break-all;line-height:1.6">${file.data || '(empty)'}</div>
      </div>`;
  }

  /* ════════════════════════════════════════
     CRASH / RECOVERY COMPARISON
  ════════════════════════════════════════ */
  function showCrashComparison(beforeFiles, afterFiles) {
    const before = document.getElementById('compareBeforeContent');
    const after  = document.getElementById('compareAfterContent');

    if (Object.keys(beforeFiles).length === 0) {
      before.innerHTML = '<div class="compare-placeholder">No files were committed before crash.</div>';
    } else {
      before.innerHTML = Object.values(beforeFiles).map(f => `
        <div class="compare-file-entry">
          <span class="cf-name">📄 ${f.name}</span>
          <span class="cf-status cf-partial">INCOMPLETE</span>
        </div>`).join('');
    }

    setTimeout(() => {
      if (Object.keys(afterFiles).length === 0) {
        after.innerHTML = '<div class="compare-placeholder">No committed files to recover.</div>';
      } else {
        after.innerHTML = Object.values(afterFiles).map(f => `
          <div class="compare-file-entry">
            <span class="cf-name">📄 ${f.name}</span>
            <span class="cf-status cf-ok">RECOVERED ✓</span>
          </div>`).join('');
      }
    }, 1200);
  }

  function runComparisonDemo() {
    const fs = JFSSimulator.getFileSystem();
    showCrashComparison(fs, fs);
    toast('info', 'Comparison Demo', 'Showing current FS state as crash/recovery comparison.');
  }

  /* ════════════════════════════════════════
     CRASH OVERLAY
  ════════════════════════════════════════ */
  function showCrashOverlay(data) {
    const overlay = document.getElementById('crashOverlay');
    const code = document.getElementById('crashCode');
    code.textContent =
      `Incomplete writes: ${data.pendingWrites?.length || 0}\n` +
      `Last TX: ${data.txId}\n` +
      `WAL entries: ${data.walLog?.length || 0}\n` +
      `Recovery: possible via WAL scan`;
    overlay.classList.add('active');
    setSystemStatus('crashed', 'System Crashed');
    document.body.style.animation = 'none';
  }

  function hideCrashOverlay() {
    document.getElementById('crashOverlay').classList.remove('active');
  }

  /* ════════════════════════════════════════
     REPLAY
  ════════════════════════════════════════ */
  function refreshReplayList() {
    const steps = JFSSimulator.getReplaySteps();
    const list = document.getElementById('replayStepsList');
    const total = document.getElementById('replayTotalSteps');
    total.textContent = steps.length;
    list.innerHTML = '';
    steps.forEach((step, i) => {
      const pill = document.createElement('div');
      pill.className = `replay-step-pill ${i < replayIndex ? 'past' : ''} ${i === replayIndex ? 'current' : ''}`;
      pill.textContent = `${i + 1}. ${step.type.toUpperCase()}`;
      pill.addEventListener('click', () => { replayIndex = i; showReplayStep(i); });
      list.appendChild(pill);
    });
    if (steps.length > 0) showReplayStep(replayIndex);
  }

  function showReplayStep(index) {
    const steps = JFSSimulator.getReplaySteps();
    if (!steps.length) return;
    const step = steps[Math.min(index, steps.length - 1)];
    if (!step) return;

    document.getElementById('replayCurrentStep').textContent = index + 1;

    const iconMap = {
      begin:    `<div class="replay-step-icon rsi-begin"><svg viewBox="0 0 20 20" fill="none"><path d="M10 3a7 7 0 100 14A7 7 0 0010 3zM10 7v3l2 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg></div>`,
      write:    `<div class="replay-step-icon rsi-write"><svg viewBox="0 0 20 20" fill="none"><path d="M13.586 3.586a2 2 0 012.828 2.828l-8.485 8.485-3.536.707.707-3.535 8.486-8.486z" stroke="currentColor" stroke-width="1.5"/></svg></div>`,
      commit:   `<div class="replay-step-icon rsi-commit"><svg viewBox="0 0 20 20" fill="none"><path d="M5 10l4 4 6-8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></div>`,
      crash:    `<div class="replay-step-icon rsi-crash"><svg viewBox="0 0 20 20" fill="none"><path d="M10 6v4M10 14h.01M3 10a7 7 0 1114 0 7 7 0 01-14 0z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg></div>`,
      recover:  `<div class="replay-step-icon rsi-recover"><svg viewBox="0 0 20 20" fill="none"><path d="M4 10a6 6 0 1012 0M4 10H2M4 10l2-2M4 10l2 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></div>`,
      rollback: `<div class="replay-step-icon rsi-crash"><svg viewBox="0 0 20 20" fill="none"><path d="M4 4l12 12M16 4L4 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg></div>`,
    };

    document.getElementById('replayStage').innerHTML = `
      <div class="replay-step-visual">
        ${iconMap[step.type] || iconMap.begin}
        <div class="replay-step-title">${step.title}</div>
        <div class="replay-step-desc">${step.desc}</div>
        <div class="replay-step-code">${step.code}</div>
      </div>`;

    // Update pills
    document.querySelectorAll('.replay-step-pill').forEach((p, i) => {
      p.className = `replay-step-pill ${i < index ? 'past' : ''} ${i === index ? 'current' : ''}`;
    });
  }

  function initReplayControls() {
    document.getElementById('replayPrev').addEventListener('click', () => {
      const steps = JFSSimulator.getReplaySteps();
      if (replayIndex > 0) { replayIndex--; showReplayStep(replayIndex); }
    });
    document.getElementById('replayNext').addEventListener('click', () => {
      const steps = JFSSimulator.getReplaySteps();
      if (replayIndex < steps.length - 1) { replayIndex++; showReplayStep(replayIndex); }
    });
    document.getElementById('replayReset').addEventListener('click', () => {
      replayIndex = 0;
      refreshReplayList();
    });
    document.getElementById('replayAuto').addEventListener('click', () => {
      if (replayAuto) {
        clearInterval(replayAuto);
        replayAuto = null;
        document.getElementById('replayAuto').textContent = '▶ Auto';
        return;
      }
      document.getElementById('replayAuto').textContent = '⏸ Pause';
      replayAuto = setInterval(() => {
        const steps = JFSSimulator.getReplaySteps();
        if (replayIndex >= steps.length - 1) {
          clearInterval(replayAuto);
          replayAuto = null;
          document.getElementById('replayAuto').textContent = '▶ Auto';
          return;
        }
        replayIndex++;
        showReplayStep(replayIndex);
      }, 2200);
    });
  }

  /* ════════════════════════════════════════
     ANALYTICS CHARTS
  ════════════════════════════════════════ */
  function refreshCharts() {
    const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
    const gridColor = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)';
    const textColor = isDark ? '#7a8fa8' : '#4a5a72';
    const history = JFSSimulator.getTxHistory();
    const opCounts = JFSSimulator.getOpCounts();

    // Transaction history chart
    const txCtx = document.getElementById('txChart');
    if (txCtx) {
      if (charts.tx) charts.tx.destroy();
      const labels = history.map((_, i) => `TX${i+1}`);
      charts.tx = new Chart(txCtx, {
        type: 'bar',
        data: {
          labels: labels.length ? labels : ['No data'],
          datasets: [
            { label: 'Duration (ms)', data: history.map(t => t.duration), backgroundColor: 'rgba(59,130,246,0.5)', borderColor: '#3b82f6', borderWidth: 1 },
            { label: 'Operations',    data: history.map(t => t.operations * 20), backgroundColor: 'rgba(34,197,94,0.5)',  borderColor: '#22c55e', borderWidth: 1 },
          ]
        },
        options: { responsive:true, plugins:{legend:{labels:{color:textColor,font:{family:'IBM Plex Sans',size:11}}}}, scales:{x:{grid:{color:gridColor},ticks:{color:textColor}},y:{grid:{color:gridColor},ticks:{color:textColor}}} }
      });
    }

    // Operation breakdown pie
    const opCtx = document.getElementById('opChart');
    if (opCtx) {
      if (charts.op) charts.op.destroy();
      const opData = Object.entries(opCounts).filter(([,v]) => v > 0);
      charts.op = new Chart(opCtx, {
        type: 'doughnut',
        data: {
          labels: opData.length ? opData.map(([k]) => k) : ['No operations'],
          datasets: [{
            data: opData.length ? opData.map(([,v]) => v) : [1],
            backgroundColor: ['rgba(59,130,246,0.7)','rgba(34,197,94,0.7)','rgba(245,158,11,0.7)','rgba(239,68,68,0.7)','rgba(139,92,246,0.7)'],
            borderColor: isDark ? '#111418' : '#ffffff',
            borderWidth: 2,
          }]
        },
        options: { responsive:true, plugins:{legend:{position:'right',labels:{color:textColor,font:{family:'IBM Plex Sans',size:11}}}} }
      });
    }

    // Ledger table
    updateLedger(history);
  }

  function updateLedger(history) {
    const tbody = document.getElementById('txLedgerBody');
    if (!history.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="table-empty">No transactions recorded yet</td></tr>';
      return;
    }
    tbody.innerHTML = history.slice().reverse().map(t => `
      <tr>
        <td>${t.id}</td>
        <td><span class="tx-status-pill txp-${t.status}">${t.status.toUpperCase()}</span></td>
        <td>${t.operations}</td>
        <td>${formatBytes(t.bytes)}</td>
        <td>${t.duration}ms</td>
        <td>${t.ts}</td>
      </tr>`).join('');
  }

  /* ════════════════════════════════════════
     EDUCATION CONTENT
  ════════════════════════════════════════ */
  const EDU_CONTENT = {
    intro: {
      title: 'Introduction to Journaling File Systems',
      subtitle: 'Understanding data integrity and crash consistency',
      body: `
        <p>A <span class="highlight">Journaling File System (JFS)</span> is a file system that maintains a special log — called a journal — that records changes before they are committed to the main file system. This technique dramatically reduces the risk of data corruption in the event of a system crash, power failure, or unexpected shutdown.</p>
        <h3>Why Journaling Matters</h3>
        <p>Traditional file systems without journaling (like FAT32) were vulnerable to corruption if a crash occurred during a multi-step write operation. For example, updating a file involves: (1) writing data, (2) updating metadata, and (3) updating the directory. If a crash occurs between steps, the file system ends up in an inconsistent state.</p>
        <div class="note-box">💡 <strong>Key Insight:</strong> Journaling ensures that either all parts of a multi-step operation complete, or none of them do — this is known as <span class="highlight">atomicity</span>.</div>
        <h3>Common Journaling File Systems</h3>
        <ul>
          <li><strong>ext3 / ext4</strong> — Linux standard, widely used</li>
          <li><strong>NTFS</strong> — Windows default file system</li>
          <li><strong>HFS+ / APFS</strong> — Apple macOS file systems</li>
          <li><strong>XFS, JFS, ReiserFS</strong> — Enterprise Linux file systems</li>
          <li><strong>ZFS, Btrfs</strong> — Advanced file systems with copy-on-write</li>
        </ul>
        <p>In this simulator, you can observe every step of the journaling process — from WAL writes to crash recovery — in real time.</p>`
    },
    wal: {
      title: 'Write-Ahead Logging (WAL)',
      subtitle: 'The fundamental technique behind journaling',
      body: `
        <p>Write-Ahead Logging (WAL) is the core mechanism behind all journaling file systems. The rule is simple but powerful: <span class="highlight">before writing any data to disk, first write a log record to the journal</span>. This ensures that no matter when a crash occurs, the system can determine exactly what was in progress and restore consistency.</p>
        <h3>How WAL Works</h3>
        <p>Each WAL record contains a Log Sequence Number (LSN), the transaction ID, the operation type, the affected data, and a timestamp. These records are written sequentially to a dedicated journal area on disk.</p>
        <div class="code-block">WAL Record Format:
[ LSN | TX-ID | OPERATION | FILE | PREV_DATA | NEW_DATA | CHECKSUM ]

Example sequence:
LSN:0001  TX-0001  BEGIN
LSN:0002  TX-0001  WRITE   report.txt  "Hello World"  block:5
LSN:0003  TX-0001  COMMIT</div>
        <h3>The WAL Protocol</h3>
        <ul>
          <li><strong>Log before disk:</strong> The journal record must be durably written before the actual data is written to its permanent location.</li>
          <li><strong>Commit logging:</strong> A COMMIT record marks the transaction as complete. Recovery replays all operations up to the last COMMIT.</li>
          <li><strong>Checkpoint:</strong> Periodically, completed journal records are flushed ("checkpointed") and the journal space is reclaimed.</li>
        </ul>
        <div class="note-box">🔑 <strong>The golden rule:</strong> No data is ever written to its final location before the corresponding journal entry is safely on disk. This is what makes recovery possible.</div>`
    },
    atomicity: {
      title: 'Atomicity & Durability (ACID)',
      subtitle: 'The guarantees that make journaling reliable',
      body: `
        <p>Journaling file systems implement two of the four ACID properties that databases also rely on: <span class="highlight">Atomicity</span> and <span class="highlight">Durability</span>.</p>
        <h3>Atomicity</h3>
        <p>A transaction is <em>atomic</em> — it either completes entirely or not at all. In a journaling FS, a transaction groups multiple write operations (data write, inode update, directory update) into a single atomic unit. If any step fails, the entire transaction is rolled back.</p>
        <div class="code-block">Atomic Transaction Example:
BEGIN TX-0001
  WRITE: data block 47 ← "New content"
  WRITE: inode update ← new size=11
  WRITE: directory ← "file.txt" entry
COMMIT TX-0001
↑ All succeed or ALL are undone</div>
        <h3>Durability</h3>
        <p>Once a transaction is committed (the COMMIT record is in the journal), it is <em>durable</em> — the changes will survive any subsequent crash. The WAL COMMIT record is the point of no return. Recovery will always redo committed transactions.</p>
        <h3>Consistency</h3>
        <p>The file system moves from one consistent state to another. Partially-written data (which would leave the FS inconsistent) is never visible to the rest of the system.</p>
        <div class="note-box">🔐 <strong>ACID in JFS:</strong> Atomicity + Durability are explicitly guaranteed. Consistency is maintained by design. Isolation is provided at the OS layer through locks.</div>`
    },
    recovery: {
      title: 'Crash Recovery via WAL',
      subtitle: 'How journaling restores consistency after a failure',
      body: `
        <p>Crash recovery is where the Write-Ahead Log proves its value. When the system restarts after a crash, the file system driver scans the WAL journal from oldest to newest and performs two phases: <span class="highlight">REDO</span> and <span class="highlight">UNDO</span>.</p>
        <h3>Recovery Algorithm</h3>
        <div class="code-block">Phase 1 — ANALYSIS: Scan WAL, categorize transactions
  → Committed TX:   has COMMIT record → REDO
  → Uncommitted TX: no COMMIT record  → UNDO

Phase 2 — REDO: Re-apply all committed TX in order
  for each committed TX:
    for each WRITE record:
      re-apply to disk (idempotent)
  → Disk now reflects all committed data

Phase 3 — UNDO: Revert all uncommitted TX
  for each uncommitted TX:
    for each WRITE record:
      restore prev_data to disk
  → Disk reverts incomplete changes</div>
        <h3>Why Recovery is Safe</h3>
        <p>Recovery operations are <em>idempotent</em> — they can be applied multiple times with the same result. If recovery itself crashes halfway through, it simply restarts and replays from the beginning. The WAL has enough information to reconstruct the correct state regardless of when the crash occurred.</p>
        <div class="note-box">⚡ <strong>Speed:</strong> Journal recovery typically takes milliseconds to seconds, compared to the hours that fsck (file system check) could take on a large un-journaled disk.</div>`
    },
    types: {
      title: 'Types of Journaling',
      subtitle: 'Trade-offs between safety and performance',
      body: `
        <p>Not all journaling is equal. There are three main modes, each offering different trade-offs between data safety and write performance.</p>
        <h3>1. Full Data Journaling</h3>
        <p>Both data and metadata are written to the journal before being committed to disk. This is the safest mode — even data blocks are protected by the WAL. However, it is the slowest because every write goes through the journal twice.</p>
        <div class="code-block">Journal: [data block] + [metadata] → Disk: data + metadata
Safety: ★★★★★  Performance: ★★☆☆☆  (ext3 data=journal)</div>
        <h3>2. Ordered Journaling (default)</h3>
        <p>Only metadata is journaled, but data blocks are written to disk <em>before</em> the metadata journal entry. This ensures data is on disk before the journal records that it exists. It offers a good balance of safety and performance.</p>
        <div class="code-block">Disk: data blocks → Journal: [metadata] → Disk: metadata
Safety: ★★★★☆  Performance: ★★★☆☆  (ext3 data=ordered, ext4 default)</div>
        <h3>3. Writeback Mode</h3>
        <p>Only metadata is journaled, with no ordering guarantee. Data blocks may be written to disk after metadata. This is the fastest mode but can lead to stale data appearing in files after a crash (though the structure remains consistent).</p>
        <div class="code-block">Journal: [metadata] → Disk: data + metadata (any order)
Safety: ★★★☆☆  Performance: ★★★★★  (ext3 data=writeback)</div>
        <div class="note-box">📊 <strong>In practice:</strong> Most Linux systems use ordered journaling (ext4 default). Databases like PostgreSQL implement their own WAL on top of the OS file system for even finer-grained control.</div>`
    },
    tradeoffs: {
      title: 'Trade-offs & Real-World Use Cases',
      subtitle: 'When to use journaling and at what level',
      body: `
        <p>Journaling solves the crash-consistency problem elegantly, but it comes with costs that system designers must consider carefully.</p>
        <h3>Performance Overhead</h3>
        <p>Every write operation generates at least one journal write, effectively doubling the I/O for metadata operations. On high-throughput systems, this overhead can be significant. Modern SSDs mitigate this with their high random-write performance.</p>
        <h3>Journal Size</h3>
        <p>The journal is typically 128MB–1GB. It is a ring buffer — after checkpointing, old entries are overwritten. If transactions accumulate faster than checkpointing can clear them, the system stalls waiting for journal space.</p>
        <h3>Use Cases</h3>
        <ul>
          <li><strong>General-purpose OS storage</strong>: ext4 ordered mode — excellent balance</li>
          <li><strong>Database files</strong>: Application-level WAL (PostgreSQL, SQLite) for fine control</li>
          <li><strong>Network storage (NAS)</strong>: ZFS with full copy-on-write provides stronger guarantees</li>
          <li><strong>Embedded systems</strong>: JFFS2, YAFFS with wear-leveling considerations</li>
          <li><strong>Read-heavy workloads</strong>: Journaling overhead negligible vs. benefit</li>
        </ul>
        <h3>Alternatives to Journaling</h3>
        <p><strong>Copy-on-Write (CoW)</strong> file systems like ZFS and Btrfs take a different approach — they never overwrite existing data. New data is always written to free blocks, and the old blocks are freed after the new write is committed. This provides atomic updates without a separate journal.</p>
        <div class="note-box">🏆 <strong>Bottom line:</strong> For almost all modern use cases, journaling is essential and should be enabled. The performance cost is far outweighed by the data integrity guarantees it provides.</div>`
    },
  };

  function initEducation() {
    document.querySelectorAll('.edu-nav-item').forEach(item => {
      item.addEventListener('click', () => {
        document.querySelectorAll('.edu-nav-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        showEduTopic(item.dataset.topic);
      });
    });
    showEduTopic('intro');
  }

  function showEduTopic(topic) {
    const content = EDU_CONTENT[topic];
    if (!content) return;
    document.getElementById('eduContent').innerHTML = `
      <div class="edu-article">
        <h2>${content.title}</h2>
        <div class="subtitle">${content.subtitle}</div>
        ${content.body}
      </div>`;
  }

  /* ════════════════════════════════════════
     SPEED SLIDER
  ════════════════════════════════════════ */
  function initSpeedSlider() {
    const slider = document.getElementById('speedSlider');
    const label  = document.getElementById('speedLabel');
    slider.addEventListener('input', () => {
      label.textContent = slider.value + '×';
    });
  }

  /* ════════════════════════════════════════
     COLOR SWATCHES
  ════════════════════════════════════════ */
  function initColorSwatches() {
    document.querySelectorAll('.swatch').forEach(sw => {
      sw.addEventListener('click', () => {
        document.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));
        sw.classList.add('active');
        const color = sw.dataset.color;
        document.documentElement.setAttribute('data-accent', color === 'blue' ? '' : color);
        localStorage.setItem('jfs_accent', color);
        toast('info', 'Accent color updated', color.charAt(0).toUpperCase() + color.slice(1));
      });
    });
    const saved = localStorage.getItem('jfs_accent');
    if (saved && saved !== 'blue') {
      document.documentElement.setAttribute('data-accent', saved);
      const sw = document.querySelector(`[data-color="${saved}"]`);
      if (sw) { document.querySelectorAll('.swatch').forEach(s => s.classList.remove('active')); sw.classList.add('active'); }
    }
  }

  /* ════════════════════════════════════════
     HELPERS
  ════════════════════════════════════════ */
  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function downloadFile(name, content, type = 'text/plain') {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([content], { type }));
    a.download = name;
    a.click();
  }

  /* ════════════════════════════════════════
     PUBLIC INIT
  ════════════════════════════════════════ */
  function init() {
    initNavigation();
    initSidebar();
    initTheme();
    initTooltips();
    initDiskGrid();
    initLogControls();
    initReplayControls();
    initSpeedSlider();
    initColorSwatches();
    startClock();
  }

  return {
    init, navigateTo, toast, setTxStatus, setSystemStatus,
    updateStateMachine, appendWALEntry, clearWALUI,
    appendJournalEntry, updateDiskUI, animateAllDiskBlocks,
    addTimelineEntry, clearTimeline, addActivity,
    updateHealthMeters, animateWALDiagram, updateStats,
    appendLog, refreshFileTree, showFileInspector,
    showCrashOverlay, hideCrashOverlay, showCrashComparison,
    runComparisonDemo, refreshReplayList, refreshCharts,
    showEduTopic, initEducation, formatBytes, downloadFile,
  };

})();
