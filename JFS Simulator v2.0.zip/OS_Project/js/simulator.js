/**
 * simulator.js
 * ─────────────────────────────────────────────────
 * Core Journaling File System simulation engine.
 * Implements: WAL, transactions, crash simulation,
 * WAL-based recovery, file system state management.
 * ─────────────────────────────────────────────────
 */

window.JFSSimulator = (function () {

  /* ── Private State ── */
  let lsn = 0;                    // Log Sequence Number
  let txCounter = 0;             // Transaction ID counter
  let currentTx = null;          // Active transaction object
  let walLog = [];               // Write-Ahead Log
  let fileSystem = {};           // Committed file system state
  let diskBlocks = new Array(128).fill('free'); // Disk block states
  let pendingWrites = [];        // Uncommitted writes in current TX
  let txHistory = [];            // All completed transactions
  let replaySteps = [];          // Steps for replay feature
  let opCounts = { CREATE:0, WRITE:0, APPEND:0, DELETE:0, RENAME:0 }; // Analytics
  let settings = {
    journalMode: 'ordered',
    blockSize: 4096,
    autoCheckpoint: true,
    crashProbability: 0,
    persist: true,
  };
  let stats = {
    transactions: 0,
    commits: 0,
    crashes: 0,
    walEntries: 0,
    files: 0,
  };

  /* ── Event Callbacks ── */
  const callbacks = {
    onWALEntry: null,
    onStateChange: null,
    onCrash: null,
    onRecovery: null,
    onJournalEntry: null,
    onLog: null,
    onDiskUpdate: null,
    onStatsUpdate: null,
  };

  /* ── Helpers ── */
  function nextLSN() { return ++lsn; }
  function nextTxId() { return `TX-${String(++txCounter).padStart(4,'0')}`; }
  function ts() { return new Date().toISOString().slice(11,23); }

  function emit(event, data) {
    if (callbacks[event]) callbacks[event](data);
  }

  function log(level, msg, detail = '') {
    emit('onLog', { level, msg, detail, time: ts() });
  }

  function walEntry(op, data = {}) {
    const entry = {
      lsn: nextLSN(),
      txId: data.txId || (currentTx ? currentTx.id : '—'),
      op,
      file: data.file || '',
      payload: data.payload || '',
      block: data.block || null,
      prevState: data.prevState || null,
      ts: ts(),
    };
    walLog.push(entry);
    stats.walEntries++;
    emit('onWALEntry', entry);
    emit('onJournalEntry', { entry, status: data.status || 'uncommitted' });
    persistState();
    return entry;
  }

  function updateDisk(blockId, state, fileInfo = '') {
    if (blockId >= 0 && blockId < 128) {
      diskBlocks[blockId] = state;
      emit('onDiskUpdate', { blockId, state, fileInfo, diskBlocks: [...diskBlocks] });
    }
  }

  function updateStats() {
    stats.files = Object.keys(fileSystem).length;
    emit('onStatsUpdate', { ...stats });
  }

  function addReplayStep(type, title, desc, code, extra = {}) {
    replaySteps.push({ type, title, desc, code, extra, ts: ts() });
  }

  /* ── Persistence ── */
  function persistState() {
    if (!settings.persist) return;
    try {
      localStorage.setItem('jfs_state', JSON.stringify({
        lsn, txCounter, walLog, fileSystem, diskBlocks,
        txHistory, stats, replaySteps, opCounts,
      }));
    } catch (e) { /* quota exceeded */ }
  }

  function loadState() {
    if (!settings.persist) return false;
    try {
      const raw = localStorage.getItem('jfs_state');
      if (!raw) return false;
      const s = JSON.parse(raw);
      lsn = s.lsn || 0;
      txCounter = s.txCounter || 0;
      walLog = s.walLog || [];
      fileSystem = s.fileSystem || {};
      diskBlocks = s.diskBlocks || new Array(128).fill('free');
      txHistory = s.txHistory || [];
      stats = s.stats || { transactions:0, commits:0, crashes:0, walEntries:0, files:0 };
      replaySteps = s.replaySteps || [];
      opCounts = s.opCounts || { CREATE:0, WRITE:0, APPEND:0, DELETE:0, RENAME:0 };
      return true;
    } catch (e) { return false; }
  }

  /* ════════════════════════════════════════
     PUBLIC API
  ════════════════════════════════════════ */

  /**
   * Start a new transaction.
   * Records BEGIN in WAL, sets up pending state.
   */
  function startTransaction() {
    if (currentTx) {
      log('warning', 'Transaction already active', `Current: ${currentTx.id}`);
      return null;
    }
    const id = nextTxId();
    currentTx = {
      id,
      startTime: Date.now(),
      writes: [],
      status: 'active',
    };
    stats.transactions++;

    walEntry('BEGIN', { txId: id, status: 'uncommitted' });
    log('info', `Transaction started`, id);

    addReplayStep('begin', 'Begin Transaction',
      `A new transaction ${id} is started. The system writes a BEGIN record to the Write-Ahead Log (WAL). No data is written to disk yet — the WAL entry ensures we can recover even if the system crashes during this transaction.`,
      `WAL ← BEGIN [LSN:${lsn}] [TX:${id}]\nStatus: ACTIVE\nDisk: unchanged`
    );

    emit('onStateChange', { state: 'active', txId: id });
    updateStats();
    return id;
  }

  /**
   * Write data within the active transaction.
   * Logs to WAL only — does NOT write to disk yet.
   */
  function writeData({ fileName, data, blockId, operation }) {
    if (!currentTx) {
      log('error', 'No active transaction', 'Start a transaction first');
      return false;
    }

    // Random crash simulation
    if (settings.crashProbability > 0) {
      if (Math.random() * 100 < settings.crashProbability) {
        setTimeout(() => simulateCrash(), 300);
        log('warning', 'Auto-crash triggered by probability setting', `${settings.crashProbability}% chance`);
      }
    }

    const write = {
      fileName: fileName || `file_${Date.now()}.txt`,
      data: data || '',
      blockId: parseInt(blockId) || 1,
      operation: operation || 'WRITE',
    };

    currentTx.writes.push(write);
    pendingWrites.push(write);
    opCounts[write.operation] = (opCounts[write.operation] || 0) + 1;

    // Mark disk block as pending (written but not committed)
    updateDisk(write.blockId - 1, 'written', write.fileName);

    const entry = walEntry('WRITE', {
      txId: currentTx.id,
      file: write.fileName,
      payload: `${write.operation}: "${write.data}" @block${write.blockId}`,
      block: write.blockId,
      prevState: fileSystem[write.fileName] || null,
      status: 'uncommitted',
    });

    log('info', `WAL write staged`, `${write.operation} "${write.fileName}" block:${write.blockId}`);

    addReplayStep('write', `Write Operation: ${write.operation}`,
      `Data for file "${write.fileName}" is first written to the WAL journal (Write-Ahead Log) with LSN ${lsn}. The actual disk block ${write.blockId} is marked PENDING. This is the key principle: log before you write. If a crash happens now, recovery will use this WAL entry.`,
      `WAL ← WRITE [LSN:${lsn}] [TX:${currentTx.id}]\n  op:${write.operation} file:"${write.fileName}"\n  data:"${write.data}"\n  block:${write.blockId} → PENDING\nDisk block ${write.blockId}: [ written / uncommitted ]`
    );

    emit('onStateChange', { state: 'writing', txId: currentTx.id });
    updateStats();
    return true;
  }

  /**
   * Commit the current transaction.
   * Writes COMMIT to WAL, then flushes to disk.
   */
  function commitTransaction() {
    if (!currentTx) {
      log('error', 'No active transaction to commit', '');
      return false;
    }
    if (currentTx.writes.length === 0) {
      log('warning', 'Committing empty transaction', currentTx.id);
    }

    const txId = currentTx.id;
    const duration = Date.now() - currentTx.startTime;
    const writes = [...currentTx.writes];

    // Step 1: Write COMMIT record to WAL
    walEntry('COMMIT', {
      txId,
      payload: `${writes.length} operations committed`,
      status: 'committed',
    });

    // Step 2: Apply writes to file system (checkpoint)
    writes.forEach(w => {
      const prevContent = fileSystem[w.fileName] ? fileSystem[w.fileName].data : null;

      if (w.operation === 'DELETE') {
        delete fileSystem[w.fileName];
        updateDisk(w.blockId - 1, 'free');
      } else if (w.operation === 'RENAME') {
        const content = fileSystem[w.fileName] || { data: '' };
        fileSystem[w.data] = { ...content, name: w.data, updatedAt: ts() };
        delete fileSystem[w.fileName];
        updateDisk(w.blockId - 1, 'committed', w.data);
      } else {
        if (!fileSystem[w.fileName]) {
          fileSystem[w.fileName] = {
            name: w.fileName, data: '', size: 0, blocks: [], createdAt: ts(), updatedAt: ts(),
          };
        }
        if (w.operation === 'APPEND') {
          fileSystem[w.fileName].data += w.data;
        } else {
          fileSystem[w.fileName].data = w.data;
        }
        fileSystem[w.fileName].size = fileSystem[w.fileName].data.length * (settings.blockSize / 4096);
        fileSystem[w.fileName].blocks = [w.blockId];
        fileSystem[w.fileName].updatedAt = ts();
        fileSystem[w.fileName].operation = w.operation;
        updateDisk(w.blockId - 1, 'committed', w.fileName);
      }
    });

    // Step 3: Record in history
    txHistory.push({
      id: txId,
      status: 'committed',
      operations: writes.length,
      bytes: writes.reduce((s, w) => s + (w.data ? w.data.length : 0), 0),
      duration,
      ts: ts(),
      writes,
    });

    stats.commits++;
    log('success', `Transaction committed`, `${txId} — ${writes.length} ops in ${duration}ms`);

    addReplayStep('commit', 'Commit Transaction',
      `The COMMIT record is written to the WAL with LSN ${lsn}. This is the point of no return — once COMMIT is in the log, the transaction is durable. The system then applies all ${writes.length} write(s) to disk and marks blocks as COMMITTED. Even if a crash happens after this WAL record, recovery will redo all operations.`,
      `WAL ← COMMIT [LSN:${lsn}] [TX:${txId}]\nCheckpointing ${writes.length} write(s) to disk:\n${writes.map(w => `  • block:${w.blockId} ${w.operation} "${w.fileName}"`).join('\n')}\nDisk blocks → COMMITTED ✓`
    );

    currentTx = null;
    pendingWrites = [];
    emit('onStateChange', { state: 'committed', txId });
    emit('onRecovery', { type: 'commit', fileSystem: { ...fileSystem } });
    updateStats();
    persistState();
    return true;
  }

  /**
   * Rollback the current transaction.
   * Writes ROLLBACK to WAL, reverts pending writes.
   */
  function rollbackTransaction() {
    if (!currentTx) {
      log('error', 'No active transaction to rollback', '');
      return false;
    }

    const txId = currentTx.id;
    const writes = [...currentTx.writes];

    // Revert disk blocks back to free/committed
    writes.forEach(w => {
      const prevState = fileSystem[w.fileName] ? 'committed' : 'free';
      updateDisk(w.blockId - 1, prevState);
    });

    walEntry('ROLLBACK', {
      txId,
      payload: `Rolled back ${writes.length} operations`,
      status: 'rolledback',
    });

    txHistory.push({
      id: txId,
      status: 'rolledback',
      operations: writes.length,
      bytes: 0,
      duration: Date.now() - currentTx.startTime,
      ts: ts(),
      writes,
    });

    addReplayStep('rollback', 'Transaction Rollback',
      `The transaction ${txId} is rolled back. A ROLLBACK record is written to the WAL. All ${writes.length} pending write(s) are discarded — disk blocks revert to their previous state. The file system is untouched, maintaining ACID atomicity.`,
      `WAL ← ROLLBACK [LSN:${lsn}] [TX:${txId}]\nReverting ${writes.length} pending write(s)...\n${writes.map(w => `  • block:${w.blockId} → reverted`).join('\n')}\nFile system: unchanged ✓`
    );

    log('warning', `Transaction rolled back`, `${txId} — ${writes.length} ops discarded`);

    currentTx = null;
    pendingWrites = [];
    emit('onStateChange', { state: 'idle', txId: null });
    updateStats();
    persistState();
    return true;
  }

  /**
   * Simulate a system crash.
   * Marks pending disk blocks as corrupt, injects CRASH record.
   */
  function simulateCrash() {
    const wasInTransaction = !!currentTx;
    const txId = currentTx ? currentTx.id : '—';

    // Corrupt all pending writes
    pendingWrites.forEach(w => {
      updateDisk(w.blockId - 1, 'corrupt', w.fileName);
    });

    // Write crash marker to WAL
    walEntry('CRASH', {
      txId,
      payload: `Kernel panic — ${pendingWrites.length} incomplete write(s) in flight`,
      status: 'crashed',
    });

    stats.crashes++;
    log('error', 'SYSTEM CRASH DETECTED', `${pendingWrites.length} incomplete writes — TX:${txId}`);

    addReplayStep('crash', 'System Crash!',
      `A crash occurred ${wasInTransaction ? `during transaction ${txId}` : 'with no active transaction'}. ${pendingWrites.length} write(s) were in-flight and NOT committed. These disk blocks are now in a CORRUPT/inconsistent state. Without the Write-Ahead Log, this data would be permanently lost or corrupted. The WAL journal is the safety net.`,
      `CRASH! [TX:${txId}]\nIn-flight writes: ${pendingWrites.length}\n${pendingWrites.map(w=>`  • "${w.fileName}" block:${w.blockId} → CORRUPT`).join('\n')}\nJournal integrity: intact ✓\nRecovery: possible via WAL`
    );

    // Abandon current transaction without committing
    currentTx = null;

    emit('onCrash', {
      txId,
      pendingWrites: [...pendingWrites],
      walLog: [...walLog],
    });
    emit('onStateChange', { state: 'crashed', txId });
    updateStats();
    persistState();
    return true;
  }

  /**
   * WAL-based crash recovery.
   * Scans WAL: redo committed TX, undo uncommitted TX.
   */
  async function recoverSystem(onStep) {
    log('info', 'Starting WAL recovery analysis', `Scanning ${walLog.length} log records...`);
    emit('onStateChange', { state: 'recovering', txId: null });

    // Identify committed and uncommitted transactions from WAL
    const txMap = {};

    for (const entry of walLog) {
      if (!txMap[entry.txId]) {
        txMap[entry.txId] = { writes: [], committed: false, rolledback: false };
      }
      if (entry.op === 'WRITE') {
        txMap[entry.txId].writes.push(entry);
      } else if (entry.op === 'COMMIT') {
        txMap[entry.txId].committed = true;
      } else if (entry.op === 'ROLLBACK') {
        txMap[entry.txId].rolledback = true;
      }
    }

    let redone = 0;
    let undone = 0;
    const recoveredFiles = {};

    // Analysis phase
    if (onStep) await onStep('analyze', `Analyzed ${Object.keys(txMap).length} transactions in WAL`);

    // REDO phase: re-apply all committed transactions
    for (const [txId, tx] of Object.entries(txMap)) {
      if (tx.committed && tx.writes.length > 0) {
        for (const w of tx.writes) {
          const blockId = w.block ? w.block - 1 : 0;
          if (diskBlocks[blockId] === 'corrupt' || diskBlocks[blockId] === 'written') {
            updateDisk(blockId, 'committed', w.file);
          }
          // Re-apply to file system
          if (w.file) {
            const op = w.payload.split(':')[0];
            if (op === 'DELETE') {
              delete fileSystem[w.file];
            } else {
              if (!fileSystem[w.file]) {
                fileSystem[w.file] = { name: w.file, data: '', size: 0, blocks: [], createdAt: ts(), updatedAt: ts() };
              }
              const dataMatch = w.payload.match(/"(.*)"/);
              if (dataMatch) fileSystem[w.file].data = dataMatch[1];
              fileSystem[w.file].updatedAt = ts();
            }
            recoveredFiles[w.file] = 'recovered';
          }
          redone++;
        }
        walEntry('RECOVER', { txId, payload: `REDO: ${tx.writes.length} ops from committed TX`, status: 'committed' });
        log('success', `REDO: committed TX recovered`, txId);
        if (onStep) await onStep('redo', `REDO: ${txId} — ${tx.writes.length} operations re-applied`);
      }
    }

    // UNDO phase: revert any uncommitted transactions
    for (const [txId, tx] of Object.entries(txMap)) {
      if (!tx.committed && !tx.rolledback && tx.writes.length > 0) {
        for (const w of tx.writes) {
          const blockId = w.block ? w.block - 1 : 0;
          updateDisk(blockId, w.prevState ? 'committed' : 'free');
          undone++;
        }
        walEntry('RECOVER', { txId, payload: `UNDO: ${tx.writes.length} ops from uncommitted TX`, status: 'rolledback' });
        log('warning', `UNDO: uncommitted TX reverted`, txId);
        if (onStep) await onStep('undo', `UNDO: ${txId} — ${tx.writes.length} operations reverted`);
      }
    }

    // Clean up remaining corrupt blocks
    diskBlocks.forEach((state, i) => {
      if (state === 'corrupt' || state === 'written') {
        diskBlocks[i] = 'free';
        emit('onDiskUpdate', { blockId: i, state: 'free', diskBlocks: [...diskBlocks] });
      }
    });

    currentTx = null;
    pendingWrites = [];

    addReplayStep('recover', 'WAL Recovery Complete',
      `Recovery is complete! The WAL was scanned from oldest to newest LSN. REDO phase applied ${redone} operation(s) from committed transactions. UNDO phase reverted ${undone} operation(s) from uncommitted transactions. The file system is now fully consistent — this is the power of Write-Ahead Logging.`,
      `Recovery Analysis:\n  Transactions scanned: ${Object.keys(txMap).length}\n  REDO (committed): ${redone} op(s) re-applied\n  UNDO (uncommitted): ${undone} op(s) reverted\n  Corrupt blocks cleaned: ✓\nFile system: CONSISTENT ✓\nData loss: NONE ✓`
    );

    log('success', 'WAL Recovery complete', `REDO:${redone} UNDO:${undone} — FS consistent`);

    emit('onRecovery', {
      type: 'full-recovery',
      redone,
      undone,
      fileSystem: { ...fileSystem },
      recoveredFiles,
    });
    emit('onStateChange', { state: 'recovered', txId: null });
    updateStats();
    persistState();
    return { redone, undone, recoveredFiles };
  }

  /* ── Getters ── */
  function getCurrentTx()  { return currentTx ? { ...currentTx } : null; }
  function getWALLog()     { return [...walLog]; }
  function getFileSystem() { return { ...fileSystem }; }
  function getDiskBlocks() { return [...diskBlocks]; }
  function getTxHistory()  { return [...txHistory]; }
  function getStats()      { return { ...stats }; }
  function getReplaySteps(){ return [...replaySteps]; }
  function getOpCounts()   { return { ...opCounts }; }
  function isCrashed()     { return diskBlocks.some(b => b === 'corrupt'); }

  function clearWAL() {
    walLog = [];
    lsn = 0;
    stats.walEntries = 0;
    emit('onStatsUpdate', { ...stats });
    persistState();
  }

  function hardReset() {
    lsn = 0; txCounter = 0; currentTx = null;
    walLog = []; fileSystem = {}; pendingWrites = [];
    txHistory = []; replaySteps = [];
    opCounts = { CREATE:0, WRITE:0, APPEND:0, DELETE:0, RENAME:0 };
    diskBlocks = new Array(128).fill('free');
    stats = { transactions:0, commits:0, crashes:0, walEntries:0, files:0 };
    try { localStorage.removeItem('jfs_state'); } catch(e) {}
    emit('onStateChange', { state: 'idle', txId: null });
    emit('onDiskUpdate', { diskBlocks: [...diskBlocks] });
    updateStats();
  }

  function updateSettings(newSettings) {
    Object.assign(settings, newSettings);
  }

  function on(event, cb) {
    if (callbacks.hasOwnProperty(event)) callbacks[event] = cb;
  }

  function init() {
    const loaded = loadState();
    updateStats();
    return loaded;
  }

  /* ── Public Interface ── */
  return {
    init, on, updateSettings,
    startTransaction, writeData, commitTransaction,
    rollbackTransaction, simulateCrash, recoverSystem,
    clearWAL, hardReset,
    getCurrentTx, getWALLog, getFileSystem, getDiskBlocks,
    getTxHistory, getStats, getReplaySteps, getOpCounts, isCrashed,
  };

})();
