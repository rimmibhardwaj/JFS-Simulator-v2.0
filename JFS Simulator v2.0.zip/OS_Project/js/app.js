/**
 * app.js
 * ─────────────────────────────────────────────────
 * Main application entry point.
 * Wires JFSSimulator engine to JFSUI layer.
 * Handles all button events, settings, export,
 * and orchestrates the full simulation flow.
 * ─────────────────────────────────────────────────
 */

(function () {
  'use strict';

  /* ── Shorthand ── */
  const SIM = window.JFSSimulator;
  const UI  = window.JFSUI;

  /* ── Simulation speed multiplier ── */
  function getSpeed() {
    const v = parseFloat(document.getElementById('speedSlider').value) || 1;
    return v;
  }

  function delay(ms) {
    return new Promise(r => setTimeout(r, ms / getSpeed()));
  }

  /* ════════════════════════════════════════
     SIMULATOR EVENT BINDINGS
  ════════════════════════════════════════ */

  /* ── Start Transaction ── */
  document.getElementById('btnStartTx').addEventListener('click', () => {
    const txId = SIM.startTransaction();
    if (!txId) return;

    // Update UI state
    UI.setTxStatus('active');
    UI.setSystemStatus('busy', 'Transaction Active');
    UI.updateStateMachine('active');
    UI.updateHealthMeters('active');
    UI.animateWALDiagram('walApp');

    // Show data input panel
    document.getElementById('dataInputPanel').classList.add('visible');

    // Enable/disable buttons
    setButtons({ start: false, write: true, commit: true, rollback: true, crash: true, recover: false });

    // Update TX display
    document.getElementById('currentTxId').textContent = txId;

    // Dashboard updates
    UI.addTimelineEntry('active', `Transaction ${txId} started`, 'BEGIN record written to WAL');
    UI.addActivity('start', `Started ${txId}`);
    UI.toast('info', 'Transaction Started', `${txId} — WAL BEGIN recorded`);
  });

  /* ── Write Data ── */
  document.getElementById('btnWriteData').addEventListener('click', () => {
    const fileName = document.getElementById('inputFileName').value.trim() || `file_${Date.now()}.txt`;
    const data     = document.getElementById('inputData').value.trim() || 'sample data';
    const block    = parseInt(document.getElementById('inputBlock').value) || 1;
    const op       = document.getElementById('inputOp').value;

    const success = SIM.writeData({ fileName, data, blockId: block, operation: op });
    if (!success) return;

    UI.setTxStatus('writing');
    UI.updateStateMachine('writing');
    UI.updateHealthMeters('writing');
    UI.animateWALDiagram('walJournal');

    const tx = SIM.getCurrentTx();
    UI.addActivity('write', `${op} "${fileName}" → block ${block}`);
    UI.toast('info', 'Write Staged to WAL', `${op} ${fileName} @ block ${block}`);

    // Auto-increment block for next write
    const blockInput = document.getElementById('inputBlock');
    blockInput.value = Math.min(128, parseInt(blockInput.value) + 1);
  });

  /* ── Commit ── */
  document.getElementById('btnCommit').addEventListener('click', async () => {
    const tx = SIM.getCurrentTx();
    if (!tx) return;
    const txId = tx.id;

    // Animate WAL → Disk flow
    UI.animateWALDiagram('walJournal');
    await delay(300);
    UI.animateWALDiagram('walDisk');

    const success = SIM.commitTransaction();
    if (!success) return;

    UI.setTxStatus('idle');
    UI.setSystemStatus('', 'System Ready');
    UI.updateStateMachine('committed');
    UI.updateHealthMeters('committed');

    await delay(600);
    UI.animateWALDiagram(null);
    UI.updateStateMachine('idle');

    document.getElementById('dataInputPanel').classList.remove('visible');
    setButtons({ start: true, write: false, commit: false, rollback: false, crash: true, recover: false });
    document.getElementById('currentTxId').textContent = '—';

    UI.addTimelineEntry('commit', `Transaction ${txId} committed`, 'All writes flushed to disk ✓');
    UI.addActivity('commit', `Committed ${txId} successfully`);
    UI.refreshFileTree();
    UI.toast('success', 'Transaction Committed', `${txId} — all writes durable on disk`);
  });

  /* ── Rollback ── */
  document.getElementById('btnRollback').addEventListener('click', () => {
    const tx = SIM.getCurrentTx();
    if (!tx) return;
    const txId = tx.id;

    const success = SIM.rollbackTransaction();
    if (!success) return;

    UI.setTxStatus('idle');
    UI.setSystemStatus('', 'System Ready');
    UI.updateStateMachine('idle');
    UI.updateHealthMeters('idle');
    UI.animateWALDiagram(null);

    document.getElementById('dataInputPanel').classList.remove('visible');
    setButtons({ start: true, write: false, commit: false, rollback: false, crash: true, recover: false });
    document.getElementById('currentTxId').textContent = '—';

    UI.addTimelineEntry('rollback', `Transaction ${txId} rolled back`, 'All pending writes discarded');
    UI.addActivity('rollback', `Rolled back ${txId}`);
    UI.toast('warning', 'Transaction Rolled Back', `${txId} — all changes discarded`);
  });

  /* ── Simulate Crash ── */
  document.getElementById('btnCrash').addEventListener('click', () => {
    // Capture current FS state before crash
    const fsBefore = { ...SIM.getFileSystem() };

    SIM.simulateCrash();

    UI.setTxStatus('crashed');
    UI.setSystemStatus('crashed', 'System Crashed');
    UI.updateStateMachine('crashed');
    UI.updateHealthMeters('crashed');
    UI.animateWALDiagram(null);

    document.getElementById('dataInputPanel').classList.remove('visible');
    setButtons({ start: false, write: false, commit: false, rollback: false, crash: false, recover: true });
    document.getElementById('currentTxId').textContent = '—';

    UI.addTimelineEntry('crash', 'SYSTEM CRASH', 'Incomplete writes detected — FS inconsistent');
    UI.addActivity('crash', 'System crash simulated');

    // Show crash overlay
    UI.showCrashOverlay({
      txId: SIM.getCurrentTx()?.id || '—',
      pendingWrites: SIM.getDiskBlocks().filter(b => b === 'corrupt'),
      walLog: SIM.getWALLog(),
    });

    // Update comparison panel
    UI.showCrashComparison(fsBefore, {});
  });

  /* ── Recover System ── */
  document.getElementById('btnRecover').addEventListener('click', async () => {
    UI.hideCrashOverlay();
    UI.setTxStatus('recovering');
    UI.setSystemStatus('busy', 'Recovering…');
    UI.updateStateMachine('recovering');
    UI.updateHealthMeters('recovering');

    setButtons({ start: false, write: false, commit: false, rollback: false, crash: false, recover: false });

    UI.addTimelineEntry('recover', 'WAL Recovery Started', 'Scanning journal for incomplete transactions');
    UI.addActivity('recover', 'WAL recovery sequence initiated');
    UI.toast('info', 'Recovery Started', 'Scanning WAL journal…');

    // Animated recovery with step callbacks
    const result = await SIM.recoverSystem(async (phase, msg) => {
      UI.toast('info', phase === 'analyze' ? 'Analysis' : phase === 'redo' ? 'REDO Phase' : 'UNDO Phase', msg);
      await delay(500);
    });

    // Animate disk blocks being restored
    const diskBlocks = SIM.getDiskBlocks();
    UI.animateAllDiskBlocks(diskBlocks);

    await delay(800);

    UI.setTxStatus('idle');
    UI.setSystemStatus('', 'System Recovered');
    UI.updateStateMachine('recovered');
    UI.updateHealthMeters('recovered');

    setButtons({ start: true, write: false, commit: false, rollback: false, crash: true, recover: false });

    UI.addTimelineEntry('recover', 'Recovery Complete', `REDO: ${result.redone} ops | UNDO: ${result.undone} ops | FS consistent ✓`);
    UI.addActivity('recover', `Recovery done — REDO:${result.redone} UNDO:${result.undone}`);

    // Update file system view
    UI.refreshFileTree();

    // Update comparison panel with recovered state
    UI.showCrashComparison(
      Object.fromEntries(Object.entries(SIM.getFileSystem()).map(([k, v]) => [k, { ...v }])),
      SIM.getFileSystem()
    );

    UI.toast('success', 'Recovery Complete', `File system is consistent. REDO:${result.redone} UNDO:${result.undone}`);

    // Reset state machine display after a delay
    await delay(2000);
    UI.updateStateMachine('idle');
    UI.setSystemStatus('', 'System Ready');
  });

  /* ── Crash Recovery from Overlay Button ── */
  document.getElementById('crashRecoverBtn').addEventListener('click', () => {
    document.getElementById('btnRecover').click();
  });

  /* ════════════════════════════════════════
     SIMULATOR ENGINE → UI CALLBACKS
  ════════════════════════════════════════ */

  SIM.on('onWALEntry', (entry) => {
    UI.appendWALEntry(entry);
  });

  SIM.on('onJournalEntry', ({ entry, status }) => {
    UI.appendJournalEntry(entry, status);
  });

  SIM.on('onLog', (entry) => {
    UI.appendLog(entry);
  });

  SIM.on('onDiskUpdate', (data) => {
    UI.updateDiskUI(data);
  });

  SIM.on('onStatsUpdate', (stats) => {
    UI.updateStats(stats);
  });

  SIM.on('onStateChange', ({ state }) => {
    // Nothing extra needed — buttons/status handled by button handlers
  });

  SIM.on('onCrash', (data) => {
    // Crash is fully handled in the button click handler
  });

  SIM.on('onRecovery', ({ type, fileSystem }) => {
    if (type === 'commit') {
      UI.refreshFileTree();
    }
  });

  /* ════════════════════════════════════════
     CLEAR / UTILITY BUTTONS
  ════════════════════════════════════════ */

  document.getElementById('clearWAL').addEventListener('click', () => {
    SIM.clearWAL();
    UI.clearWALUI();
    document.getElementById('journalEntries').innerHTML = '<div class="journal-empty">Journal cleared.</div>';
    document.getElementById('journalEntryCount').textContent = '0 entries';
    document.getElementById('navBadge').textContent = '0';
    UI.toast('info', 'WAL Cleared', 'Log sequence reset to 0');
  });

  document.getElementById('clearTimeline').addEventListener('click', () => {
    UI.clearTimeline();
  });

  document.getElementById('refreshFS').addEventListener('click', () => {
    UI.refreshFileTree();
    UI.toast('info', 'File system refreshed', '');
  });

  /* ════════════════════════════════════════
     SETTINGS
  ════════════════════════════════════════ */

  document.getElementById('settingJournalMode').addEventListener('change', e => {
    SIM.updateSettings({ journalMode: e.target.value });
    UI.toast('info', 'Journaling Mode Updated', e.target.options[e.target.selectedIndex].text);
  });

  document.getElementById('settingBlockSize').addEventListener('change', e => {
    SIM.updateSettings({ blockSize: parseInt(e.target.value) });
    UI.toast('info', 'Block Size Updated', e.target.options[e.target.selectedIndex].text);
  });

  document.getElementById('settingCheckpoint').addEventListener('change', e => {
    SIM.updateSettings({ autoCheckpoint: e.target.checked });
    UI.toast('info', 'Auto-Checkpoint ' + (e.target.checked ? 'Enabled' : 'Disabled'), '');
  });

  document.getElementById('settingCrashProb').addEventListener('input', e => {
    const val = parseInt(e.target.value);
    document.getElementById('crashProbLabel').textContent = val + '%';
    SIM.updateSettings({ crashProbability: val });
  });

  document.getElementById('settingPersist').addEventListener('change', e => {
    SIM.updateSettings({ persist: e.target.checked });
    UI.toast('info', 'State Persistence ' + (e.target.checked ? 'Enabled' : 'Disabled'), '');
  });

  /* ── Hard Reset ── */
  document.getElementById('hardReset').addEventListener('click', () => {
    if (!confirm('Reset everything? All transactions, logs, and file system data will be cleared.')) return;
    SIM.hardReset();

    // Reset all UI
    UI.clearWALUI();
    UI.clearTimeline();
    document.getElementById('journalEntries').innerHTML = '<div class="journal-empty">Journal is empty.<br/>Start a transaction.</div>';
    document.getElementById('journalEntryCount').textContent = '0 entries';
    document.getElementById('navBadge').textContent = '0';
    document.getElementById('walEntryCount').textContent = '0 records';
    document.getElementById('activityList').innerHTML = '<div class="activity-empty">No activity yet</div>';
    document.getElementById('fsTreeChildren').innerHTML = '<div class="tree-empty-msg">No files committed yet.</div>';
    document.getElementById('fsInspector').innerHTML = '<div class="inspector-empty"><p>Select a file to inspect</p></div>';
    document.getElementById('fsBadge').textContent = '0 files';
    document.getElementById('compareBeforeContent').innerHTML = '<div class="compare-placeholder">Run crash demo →</div>';
    document.getElementById('compareAfterContent').innerHTML  = '<div class="compare-placeholder">Awaiting recovery...</div>';
    document.getElementById('currentTxId').textContent = '—';
    document.getElementById('txLedgerBody').innerHTML = '<tr><td colspan="6" class="table-empty">No transactions recorded yet</td></tr>';

    // Reset buttons and state
    setButtons({ start: true, write: false, commit: false, rollback: false, crash: true, recover: false });
    UI.setTxStatus('idle');
    UI.setSystemStatus('', 'System Ready');
    UI.updateStateMachine('idle');
    UI.updateHealthMeters('idle');
    UI.animateWALDiagram(null);
    UI.updateStats({ transactions: 0, commits: 0, crashes: 0, walEntries: 0, files: 0 });

    // Reset disk grid
    for (let i = 0; i < 128; i++) {
      const el = document.getElementById(`block-${i}`);
      if (el) el.className = 'disk-block';
    }
    document.getElementById('diskUsed').textContent = '0';
    document.getElementById('diskCommitted').textContent = '0';
    document.getElementById('diskPending').textContent = '0';
    document.getElementById('diskCorrupt').textContent = '0';

    // Reset meters
    setMeterRaw('meterJournal', 'meterJournalBar', 100, 'fill-green');
    setMeterRaw('meterFS',      'meterFSBar',      100, 'fill-blue');
    setMeterRaw('meterDisk',    'meterDiskBar',    0,   'fill-amber');
    setMeterRaw('meterCache',   'meterCacheBar',   0,   'fill-purple');

    // Clear log terminal
    document.querySelectorAll('#logTerminal .log-line').forEach(l => l.remove());

    UI.toast('success', 'Simulator Reset', 'All state cleared — ready for new session');
  });

  /* ── Export All Data ── */
  document.getElementById('exportAllData').addEventListener('click', () => {
    const data = {
      exportedAt: new Date().toISOString(),
      stats: SIM.getStats(),
      walLog: SIM.getWALLog(),
      fileSystem: SIM.getFileSystem(),
      txHistory: SIM.getTxHistory(),
      diskBlocks: SIM.getDiskBlocks(),
      replaySteps: SIM.getReplaySteps(),
    };
    UI.downloadFile('jfs-simulation-export.json', JSON.stringify(data, null, 2), 'application/json');
    UI.toast('success', 'Data Exported', 'jfs-simulation-export.json downloaded');
  });

  /* ════════════════════════════════════════
     INPUT HELPERS
  ════════════════════════════════════════ */

  // Allow Enter key on data inputs to trigger write
  ['inputFileName', 'inputData', 'inputBlock'].forEach(id => {
    document.getElementById(id).addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const writeBtn = document.getElementById('btnWriteData');
        if (!writeBtn.disabled) writeBtn.click();
      }
    });
  });

  /* ════════════════════════════════════════
     BUTTON STATE MANAGER
  ════════════════════════════════════════ */
  function setButtons({ start, write, commit, rollback, crash, recover }) {
    btn('btnStartTx',  start);
    btn('btnWriteData', write);
    btn('btnCommit',   commit);
    btn('btnRollback', rollback);
    btn('btnCrash',    crash);
    btn('btnRecover',  recover);
  }

  function btn(id, enabled) {
    const el = document.getElementById(id);
    if (el) el.disabled = !enabled;
  }

  function setMeterRaw(labelId, barId, val, cls) {
    document.getElementById(labelId).textContent = val + '%';
    const bar = document.getElementById(barId);
    bar.style.width = val + '%';
    bar.className = `meter-fill ${cls}`;
  }

  /* ════════════════════════════════════════
     DEMO SCENARIO — Auto-run a crash demo
     on the Comparison page
  ════════════════════════════════════════ */
  document.getElementById('runComparison').addEventListener('click', () => {
    const fs = SIM.getFileSystem();
    const before = document.getElementById('compareBeforeContent');
    const after  = document.getElementById('compareAfterContent');

    const files = Object.values(fs);

    if (files.length === 0) {
      // Run a built-in demo if no real data exists
      runBuiltInCrashDemo(before, after);
    } else {
      // Show real current state
      before.innerHTML = files.map(f => `
        <div class="compare-file-entry">
          <span class="cf-name">📄 ${f.name}</span>
          <span class="cf-status cf-ok">COMMITTED</span>
        </div>`).join('');

      setTimeout(() => {
        after.innerHTML = files.map(f => `
          <div class="compare-file-entry">
            <span class="cf-name">📄 ${f.name}</span>
            <span class="cf-status cf-ok">RECOVERED ✓</span>
          </div>`).join('');
      }, 900);
    }
  }, { once: false });

  function runBuiltInCrashDemo(before, after) {
    const demoFiles = [
      { name: 'database.db',   status: 'partial' },
      { name: 'config.json',   status: 'missing' },
      { name: 'userdata.bin',  status: 'partial' },
      { name: 'index.html',    status: 'ok'      },
    ];

    before.innerHTML = demoFiles.map(f => `
      <div class="compare-file-entry">
        <span class="cf-name">📄 ${f.name}</span>
        <span class="cf-status cf-${f.status}">${f.status === 'ok' ? 'COMPLETE' : f.status === 'missing' ? 'MISSING' : 'INCOMPLETE'}</span>
      </div>`).join('');

    let delay = 400;
    demoFiles.forEach(f => {
      setTimeout(() => {
        const entries = after.querySelectorAll('.compare-file-entry');
        if (!entries.length && f === demoFiles[0]) after.innerHTML = '';
        const div = document.createElement('div');
        div.className = 'compare-file-entry';
        div.innerHTML = `
          <span class="cf-name">📄 ${f.name}</span>
          <span class="cf-status cf-ok">RECOVERED ✓</span>`;
        div.style.animation = 'fadeUp 0.2s ease';
        after.appendChild(div);
      }, delay);
      delay += 350;
    });

    UI.toast('info', 'Crash Demo', 'Showing built-in crash/recovery scenario');
  }

  /* ════════════════════════════════════════
     RESTORE PERSISTED STATE TO UI
  ════════════════════════════════════════ */
  function restoreStateToUI() {
    const walLog = SIM.getWALLog();
    const diskBlocks = SIM.getDiskBlocks();

    // Re-render WAL stream
    if (walLog.length > 0) {
      walLog.forEach(entry => {
        UI.appendWALEntry(entry);
        UI.appendJournalEntry(entry, entry.op === 'COMMIT' ? 'committed' : entry.op === 'ROLLBACK' ? 'rolledback' : 'uncommitted');
      });
    }

    // Re-render disk blocks
    UI.animateAllDiskBlocks(diskBlocks);

    // Re-render file tree
    UI.refreshFileTree();

    // Re-render stats
    UI.updateStats(SIM.getStats());

    // Re-render tx history
    const history = SIM.getTxHistory();
    history.forEach(tx => {
      UI.addTimelineEntry(
        tx.status === 'committed' ? 'commit' : tx.status === 'rolledback' ? 'rollback' : 'crash',
        `${tx.id} — ${tx.status.toUpperCase()}`,
        `${tx.operations} operations • ${tx.ts}`
      );
      UI.addActivity(
        tx.status === 'committed' ? 'commit' : 'rollback',
        `${tx.status === 'committed' ? 'Committed' : 'Rolled back'} ${tx.id}`
      );
    });

    if (history.length) {
      UI.toast('info', 'Session Restored', `Loaded ${walLog.length} WAL entries and ${history.length} transactions`);
    }
  }

  /* ════════════════════════════════════════
     KEYBOARD SHORTCUTS
  ════════════════════════════════════════ */
  document.addEventListener('keydown', e => {
    // Ignore when typing in inputs
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;

    const key = e.key.toLowerCase();
    if (e.ctrlKey || e.metaKey) {
      switch (key) {
        case 't': e.preventDefault(); document.getElementById('btnStartTx').click(); break;
        case 'w': e.preventDefault(); document.getElementById('btnWriteData').click(); break;
        case 'enter': e.preventDefault(); document.getElementById('btnCommit').click(); break;
        case 'z': e.preventDefault(); document.getElementById('btnRollback').click(); break;
      }
    }
  });

  /* ════════════════════════════════════════
     TOOLTIPS — dynamic ones on disk blocks
  ════════════════════════════════════════ */
  function attachDynamicTooltips() {
    const tip = document.getElementById('globalTooltip');
    document.getElementById('diskGrid').addEventListener('mouseover', e => {
      const block = e.target.closest('.disk-block');
      if (!block) return;
      const idx = parseInt(block.id.replace('block-', ''));
      const state = SIM.getDiskBlocks()[idx] || 'free';
      const fs = SIM.getFileSystem();
      const file = Object.values(fs).find(f => f.blocks && f.blocks.includes(idx + 1));
      tip.textContent = `Block ${idx + 1} — ${state.toUpperCase()}${file ? ` — ${file.name}` : ''}`;
      tip.classList.add('visible');
    });
    document.getElementById('diskGrid').addEventListener('mousemove', e => {
      tip.style.left = (e.clientX + 14) + 'px';
      tip.style.top  = (e.clientY - 8)  + 'px';
    });
    document.getElementById('diskGrid').addEventListener('mouseleave', () => {
      tip.classList.remove('visible');
    });
  }

  /* ════════════════════════════════════════
     BOOT SEQUENCE
  ════════════════════════════════════════ */
  function boot() {
    // 1. Initialize UI layer
    UI.init();

    // 2. Initialize simulator engine (loads persisted state if available)
    const hadSavedState = SIM.init();

    // 3. Set initial button states
    setButtons({ start: true, write: false, commit: false, rollback: false, crash: true, recover: false });

    // 4. Set initial UI state
    UI.setTxStatus('idle');
    UI.setSystemStatus('', 'System Ready');
    UI.updateStateMachine('idle');
    UI.updateHealthMeters('idle');

    // 5. Attach dynamic tooltips
    attachDynamicTooltips();

    // 6. Restore persisted state to UI if available
    if (hadSavedState) {
      restoreStateToUI();
    } else {
      // Write a welcome log entry
      SIM.on('onLog', (entry) => UI.appendLog(entry)); // ensure binding is live
      UI.appendLog({
        level: 'info',
        msg: 'JFS Simulator v2.0 initialized',
        detail: 'Ready — open Simulator to begin',
        time: new Date().toISOString().slice(11, 23),
      });
      UI.appendLog({
        level: 'info',
        msg: 'Tip: Ctrl+T = Start TX, Ctrl+Enter = Commit, Ctrl+Z = Rollback',
        detail: '',
        time: new Date().toISOString().slice(11, 23),
      });
    }

    console.log('%c JFS Simulator v2.0 ', 'background:#3b82f6;color:#fff;font-weight:700;font-size:14px;padding:4px 8px;border-radius:4px;');
    console.log('%c Journaling File System Simulator — ready.', 'color:#7a8fa8;font-size:12px;');
  }

  // Launch on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

})();
